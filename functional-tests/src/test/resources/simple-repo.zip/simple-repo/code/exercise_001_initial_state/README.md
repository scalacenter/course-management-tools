Initial state

Project running on Scala 2

