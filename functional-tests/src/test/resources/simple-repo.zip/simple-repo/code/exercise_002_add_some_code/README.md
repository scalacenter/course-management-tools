Change the source code a bit

