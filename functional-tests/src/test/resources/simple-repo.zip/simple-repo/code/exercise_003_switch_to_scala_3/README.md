Switch the Scala version from 2 to 3

